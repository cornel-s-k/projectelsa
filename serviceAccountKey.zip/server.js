// Import library yang dibutuhkan
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

// Masukkan Service Account Key Anda di sini
const serviceAccount = require('./serviceAccountKey.json');

// Inisialisasi Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  projectId: serviceAccount.project_id // tambahkan eksplisit projectId
});

const db = admin.firestore();
const app = express();
const port = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Endpoint untuk menerima data survei
app.post('/api/submit-survey', async (req, res) => {
  try {
    const { userId, ...surveyData } = req.body;

    if (!userId) {
      return res.status(400).send('User ID is required.');
    }

    console.log('Firestore Project ID:', serviceAccount.project_id);
    console.log('Received userId:', userId);
    const collectionPath = `users/${userId}/survey_responses`;
    console.log('Constructed collection path:', collectionPath);

    const ref = await db.collection(collectionPath).add({
      ...surveyData,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });

    console.log('Document written with ID:', ref.id);
    res.status(200).send('Data survei berhasil disimpan.');
  } catch (error) {
    console.error('Error saving survey data:', error.code, error.message);
    res.status(500).send(`Terjadi kesalahan saat menyimpan data: ${error.message}`);
  }
});

app.get('/api/get-results', async (req, res) => {
  try {
    const userId = req.query.userId;
    if (!userId) {
      return res.status(400).send('User ID is required.');
    }

    const collectionPath = `users/${userId}/survey_responses`;
    const snapshot = await db.collection(collectionPath).orderBy('timestamp', 'desc').get();

    const results = [];
    snapshot.forEach(doc => {
      const data = doc.data();

      let submissionDate = null;
      if (data.timestamp && data.timestamp.toDate) {
        submissionDate = data.timestamp.toDate().toLocaleString('id-ID');
      }

      results.push({
        id: doc.id,
        ...data,
        submissionDate // selalu ada field ini meski null
      });
    });

    res.status(200).json(results);
  } catch (error) {
    console.error('Error fetching survey data:', error.code, error.message);
    res.status(500).send(`Terjadi kesalahan saat mengambil data: ${error.message}`);
  }
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server backend berjalan di http://localhost:${port}`);
});

